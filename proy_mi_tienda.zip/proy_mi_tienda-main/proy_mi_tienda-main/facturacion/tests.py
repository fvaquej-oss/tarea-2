from django.test import TestCase
from django.contrib.auth import get_user_model
from django.urls import reverse

from .models import Marca, Producto


class InventoryAccessTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_user(
            username="admin",
            password="test-password-123",
        )
        self.marca = Marca.objects.create(nombre="Samsung")
        self.producto = Producto.objects.create(
            nombre="Laptop",
            marca=self.marca,
            precio="100.00",
        )

    def test_inventory_pages_are_public_and_use_absolute_static_urls(self):
        for route_name in ("facturacion:marca_lista", "facturacion:producto_lista"):
            with self.subTest(route=route_name):
                response = self.client.get(reverse(route_name))
                self.assertEqual(response.status_code, 200)
                self.assertContains(response, 'href="/static/css/estilos.css"')

    def test_inventory_changes_require_login(self):
        protected_urls = (
            reverse("facturacion:marca_crear"),
            reverse("facturacion:marca_editar", args=[self.marca.pk]),
            reverse("facturacion:marca_eliminar", args=[self.marca.pk]),
            reverse("facturacion:producto_crear"),
            reverse("facturacion:producto_editar", args=[self.producto.pk]),
            reverse("facturacion:producto_eliminar", args=[self.producto.pk]),
        )

        for url in protected_urls:
            with self.subTest(url=url):
                response = self.client.get(url)
                self.assertRedirects(response, f"{reverse('login')}?next={url}")

    def test_logged_in_user_can_open_inventory_forms(self):
        self.client.force_login(self.user)
        protected_urls = (
            reverse("facturacion:marca_crear"),
            reverse("facturacion:marca_editar", args=[self.marca.pk]),
            reverse("facturacion:marca_eliminar", args=[self.marca.pk]),
            reverse("facturacion:producto_crear"),
            reverse("facturacion:producto_editar", args=[self.producto.pk]),
            reverse("facturacion:producto_eliminar", args=[self.producto.pk]),
        )

        for url in protected_urls:
            with self.subTest(url=url):
                self.assertEqual(self.client.get(url).status_code, 200)
